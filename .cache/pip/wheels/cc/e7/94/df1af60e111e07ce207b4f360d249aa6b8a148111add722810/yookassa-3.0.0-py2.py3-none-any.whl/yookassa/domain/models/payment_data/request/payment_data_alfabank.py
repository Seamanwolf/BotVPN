# -*- coding: utf-8 -*-
from deprecated import deprecated
from yookassa.domain.common.payment_method_type import PaymentMethodType
from yookassa.domain.models.payment_data.payment_data import PaymentData


@deprecated("This class will be removed in one of future versions")
class PaymentDataAlfabank(PaymentData):
    __login = None

    def __init__(self, *args, **kwargs):
        super(PaymentDataAlfabank, self).__init__(*args, **kwargs)
        if self.type is None or self.type is not PaymentMethodType.ALFABANK:
            self.type = PaymentMethodType.ALFABANK

    @property
    def login(self):
        return self.__login

    @login.setter
    def login(self, value):
        self.__login = str(value)
