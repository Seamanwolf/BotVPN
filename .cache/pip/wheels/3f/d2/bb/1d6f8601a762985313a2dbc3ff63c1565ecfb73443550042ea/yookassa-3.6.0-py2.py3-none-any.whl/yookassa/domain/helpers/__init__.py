# -*- coding: utf-8 -*-

from yookassa.domain.helpers.product_code import ProductCode
