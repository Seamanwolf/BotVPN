# -*- coding: utf-8 -*-
"""Top-level package for YooKassa API Python Client Library."""
